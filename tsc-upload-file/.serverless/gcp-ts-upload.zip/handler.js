'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
var storage_1 = require("@google-cloud/storage");
// Creates a client
var storage = new storage_1.Storage();
var bucketName = 'sls-gcp-python-hello-world-dev-1571718042216';
exports.http = function (request, response) {
    var files = request.files;
    response.status(200).send("" + JSON.stringify(request));
};
exports.event = function (event, callback) {
    callback();
};
//# sourceMappingURL=handler.js.map